# Study Anything WorkBuddy Plugin Pack

Run the WorkBuddy inline learning workflow first, while keeping constrained OpenAPI HTTP tools as a fallback for workspaces that can call a local or private runtime.

## Import Assets

- `scripts/workbuddy_learning_flow.py`
- `platform/schemas/workbuddy-learning-input-v1.schema.json`
- `platform/schemas/workbuddy-learning-output-v1.schema.json`
- `platform/generated/study-anything-platform-openapi.json`
- `platform/generated/study-anything-tool-catalog.md`
- `platform/packs/workbuddy/pack.json`

## Local Runtime

1. Prefer inline mode: `python3 scripts/workbuddy_learning_flow.py demo --case deepseek-pm-interview`.
2. Let WorkBuddy own real model/search/file/context work and pass structured JSON to the inline script.
3. Use OpenAPI/local HTTP only as fallback when the workspace can reach the endpoint.

## Verification

- `python3 scripts/verify_workbuddy_inline_learning_flow.py --check`
- `python3 scripts/workbuddy_learning_flow.py demo --case deepseek-pm-interview`
- `API_BASE=http://127.0.0.1:8000 python3 scripts/verify_platform_agent_tools.py`
- `python3 scripts/verify_platform_operator_drill.py --check`

## Privacy Boundary

Real model credentials, browser access, external app context, and private tools stay in the user's
platform Agent or gateway. Study Anything only owns the local learning workflow, validation,
redacted evidence, and export contracts.

## Known Limitations

- Inline mode expects WorkBuddy or the platform Agent to generate teaching, quiz, and grading content.
- HTTP/OpenAPI tools are fallback assets and still require the host workspace to reach the configured endpoint.
- Real model credentials and browser/app access remain owned by WorkBuddy or the user's platform Agent.
