# Study Anything WorkBuddy Plugin Pack

Import the constrained OpenAPI HTTP tools into WorkBuddy-style workspaces that can call a local or private Study Anything runtime.

## Import Assets

- `platform/generated/study-anything-platform-openapi.json`
- `platform/generated/study-anything-tool-catalog.md`
- `platform/packs/workbuddy/pack.json`

## Local Runtime

1. Start the local Study Anything runtime with `./START_HERE.command` or `./scripts/start_here.sh`.
2. Import the assets above into workbuddy.
3. Point the host Agent or workspace at `http://127.0.0.1:8000` or your private runtime endpoint.

## Verification

- `./START_HERE.command`
- `API_BASE=http://127.0.0.1:8000 python3 scripts/verify_platform_agent_tools.py`
- `python3 scripts/verify_platform_operator_drill.py --check`

## Privacy Boundary

Real model credentials, browser access, external app context, and private tools stay in the user's
platform Agent or gateway. Study Anything only owns the local learning workflow, validation,
redacted evidence, and export contracts.

## Known Limitations

- Requires the host workspace to reach the configured local or private HTTP endpoint.
- This is an import package, not an official marketplace listing.
- Real model credentials and browser/app access remain owned by WorkBuddy or the user's platform Agent.
