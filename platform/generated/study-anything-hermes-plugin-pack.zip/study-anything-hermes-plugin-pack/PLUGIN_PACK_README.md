# Study Anything Hermes Agent Plugin Pack

Expose Study Anything to Hermes Agent through the Hermes Skills system and local HTTP/CLI tools while Hermes keeps model credentials, memory, browser/app access, MCP servers, and user conversation.

## Import Assets

- `skills/study-anything/SKILL.md`
- `platform/generated/study-anything-platform-openapi.json`
- `platform/generated/study-anything-tool-catalog.md`
- `platform/packs/hermes/pack.json`
- `docs/use-with-hermes.md`

## Local Runtime

1. Start the local Study Anything runtime with `./START_HERE.command` or `./scripts/start_here.sh`.
2. Import the assets above into hermes.
3. Point the host Agent or workspace at `http://127.0.0.1:8000` or your private runtime endpoint.

## Verification

- `hermes skills install https://raw.githubusercontent.com/jzvcpe-goat/study-anything/main/skills/study-anything/SKILL.md --name study-anything --yes`
- `./START_HERE.command`
- `python3 scripts/study_anything_cli.py health`
- `API_BASE=http://127.0.0.1:8000 python3 scripts/verify_platform_agent_tools.py`
- `python3 scripts/verify_platform_plugin_packs.py --platform hermes --check`

## Privacy Boundary

Real model credentials, browser access, external app context, and private tools stay in the user's
platform Agent or gateway. Study Anything only owns the local learning workflow, validation,
redacted evidence, and export contracts.

## Known Limitations

- This pack is a Hermes Skill and local HTTP/CLI import helper, not a published Hermes-native Python plugin repo.
- Do not claim `hermes plugins install jzvcpe-goat/study-anything` works until a standalone plugin repo is released and field-tested.
- Real model credentials, memory, browser/app access, MCP servers, and outside tools stay in Hermes or the user's private gateway.
