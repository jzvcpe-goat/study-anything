# Auditor Start Here

Package status: `ready_for_independent_audit`

This is an audit preparation pack, not an audit report or security certificate.

1. Verify `study-anything-external-security-audit-pack.zip` against the published SHA-256 sidecar.
2. Pin the exact repository commit under review.
3. Read `security/audit/README.md`, `threat-model.md`, and
   `rules-of-engagement.md`.
4. Confirm the seven scope areas in `security/audit/audit-plan.json`.
5. Run the listed evidence commands from the pinned repository checkout.
6. Perform independent source review and negative testing.
7. Return schema-valid findings and a signed machine-readable report.

The implementation team may remediate findings, but it cannot sign the
independent audit decision.
