# Study Anything Release Cleanroom Bootstrap

This archive contains the standalone release bootloader and a public evidence
report for `v0.3.29-alpha`.

Start with:

```bash
python3 platform/bootstrap/study_anything_release_bootstrap.py --tag v0.3.29-alpha --runtime metadata-only
```

The bootloader does not store real model keys. Runtime mode delegates real model
work to the user's own platform Agent or to the deterministic demo Agent.
