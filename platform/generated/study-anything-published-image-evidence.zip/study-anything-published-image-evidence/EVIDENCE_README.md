# Study Anything Published Image Evidence

Version: v0.3.27-alpha
Schema: published-image-evidence-v1

Run `python3 scripts/verify_published_image_evidence.py --check` in the repo, or
`python3 scripts/verify_published_image_evidence.py --pack platform/generated/study-anything-platform-adoption-pack.zip`
against the adoption pack.
