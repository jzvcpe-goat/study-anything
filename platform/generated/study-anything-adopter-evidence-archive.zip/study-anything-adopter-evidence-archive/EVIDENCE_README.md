# Study Anything Adopter Evidence Archive

Version: v0.3.30-alpha
Schema: adopter-evidence-archive-v1

Run `python3 scripts/verify_adopter_evidence_archive.py --check` in the repo, or
`python3 scripts/verify_adopter_evidence_archive.py --pack platform/generated/study-anything-platform-adoption-pack.zip`
against the adoption pack.
