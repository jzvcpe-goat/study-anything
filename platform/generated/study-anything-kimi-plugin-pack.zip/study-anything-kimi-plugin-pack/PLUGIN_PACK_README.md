# Study Anything Kimi Plugin Pack

Import OpenAI-compatible tool definitions into Kimi-compatible hosts and call the local or private Study Anything HTTP runtime.

## Import Assets

- `platform/generated/study-anything-openai-tools.json`
- `platform/generated/study-anything-platform-openapi.json`
- `platform/generated/study-anything-tool-catalog.md`
- `platform/packs/kimi/pack.json`

## Local Runtime

1. Start the local Study Anything runtime with `./START_HERE.command` or `./scripts/start_here.sh`.
2. Import the assets above into kimi.
3. Point the host Agent or workspace at `http://127.0.0.1:8000` or your private runtime endpoint.

## Verification

- `./START_HERE.command`
- `python3 scripts/verify_openai_compatible_gateway.py --contract-only`
- `API_BASE=http://127.0.0.1:8000 python3 scripts/verify_platform_agent_tools.py`

## Privacy Boundary

Real model credentials, browser access, external app context, and private tools stay in the user's
platform Agent or gateway. Study Anything only owns the local learning workflow, validation,
redacted evidence, and export contracts.

## Known Limitations

- Kimi web or workspace policy may block direct localhost calls; use a private gateway when needed.
- Manual gateway startup is transitional; Kimi Work or another platform Agent should own model configuration.
- Study Anything does not store real model API keys.
