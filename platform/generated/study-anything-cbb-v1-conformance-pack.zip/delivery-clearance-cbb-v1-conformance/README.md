# Delivery Clearance CBB Protocol v1 Conformance Pack

Run the independent consumer after extracting this archive:

```bash
python3 -I consumer/python/cbb_v1_consumer.py --pack-root .
```

The consumer does not import the Study Anything package. The optional project `cryptography` dependency is required only to verify Ed25519 fixture signatures.

Passing proves fixture-bounded local interoperability only. It is not production approval, certification, customer-outcome proof, or an independent audit.
