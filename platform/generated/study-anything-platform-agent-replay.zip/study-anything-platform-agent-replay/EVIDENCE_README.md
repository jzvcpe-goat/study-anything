# Study Anything Platform Agent Release Replay

Version: v0.3.29-alpha
Schema: platform-agent-release-replay-v1

Run `python3 scripts/replay_platform_agent_from_release.py --tag v0.3.29-alpha --platform kimi --runtime metadata-only`
to verify release asset import readiness, then use `--runtime skill-mode` or
`--runtime external-api --api-base <url>` for tool-call replay.
