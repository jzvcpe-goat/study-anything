# Study Anything Platform Adoption Pack

This archive is the copy-ready integration bundle for Kimi Work, Codex,
WorkBuddy-style HTTP tool workspaces, and other platform Agents.

Use it when the platform Agent owns browsing, files, video slicing, outside
tools, real model credentials, and conversation. Study Anything owns the
source-bound learning workflow, state, audit, eval evidence, retrieval quality,
and Obsidian/NotebookLM handoff.

## Quick Start

1. Start Study Anything locally with Skill Mode or the published Docker image.
2. Import `platform/generated/study-anything-platform-openapi.json` or
   `platform/generated/study-anything-openai-tools.json` into your platform.
3. Follow the operator guide for your platform under `platform/packs/`.
4. Run:

```bash
python3 scripts/verify_external_adoption.py --pack platform/generated/study-anything-platform-adoption-pack.zip --copy-worktree
```

The verifier emits `adoption-proof-v1` JSON. Treat that JSON as the minimum
acceptance evidence before claiming an external platform integration works.
The generated `adopter-evidence-archive-v1` package is the public maintainer
handoff bundle for release proof, checksums, and local GHCR pull-timeout
fallback evidence.

## Privacy

Do not put real model API keys in Study Anything. Keep real model credentials
inside the user's own Agent or platform runtime. The adoption evidence is
designed to be redacted and must not include raw source text, long answers,
agent endpoints with secrets, or platform-private browsing/video context.
