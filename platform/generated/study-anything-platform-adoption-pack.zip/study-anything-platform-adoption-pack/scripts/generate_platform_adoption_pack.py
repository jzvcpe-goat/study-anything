#!/usr/bin/env python3
"""Generate the distributable platform adoption pack archive."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any

from localhost_diagnostics import redact_diagnostic


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_DIR = ROOT / "platform" / "generated"
MANIFEST_PATH = OUTPUT_DIR / "study-anything-platform-adoption-pack.json"
ARCHIVE_PATH = OUTPUT_DIR / "study-anything-platform-adoption-pack.zip"
ARCHIVE_ROOT = "study-anything-platform-adoption-pack"
SELF_REFERENTIAL_OUTPUTS = {
    "platform/generated/study-anything-platform-adoption-pack.json",
    "platform/generated/study-anything-platform-adoption-pack.zip",
    "platform/generated/study-anything-platform-bundle.json",
}


PACK_FILES: list[tuple[str, str, str]] = [
    ("README.md", "root_doc", "Repository overview and local-first launch entrypoint."),
    ("QUICKSTART.md", "root_doc", "Ultra-short Chinese first-run guide."),
    ("docs/getting-started.md", "operator_doc", "Chinese-first beginner guide and one-command launch path."),
    ("docs/adoption.md", "operator_doc", "Clean-clone and published-image adoption guide."),
    ("docs/github-launch.md", "operator_doc", "GitHub launch, tag, release, and published-image verification guide."),
    ("docs/platform-agent-integrations.md", "operator_doc", "General external platform Agent integration guide."),
    ("docs/platform-agent-release-replay.md", "operator_doc", "Release-asset platform Agent replay simulator guide."),
    ("docs/learning-enrichment.md", "operator_doc", "Learning Enrichment Layer context contract and micro-lesson export guide."),
    ("docs/second-brain-handoff.md", "operator_doc", "Strict Obsidian, NotebookLM-style, and local archive handoff guide."),
    ("docs/obsidian-export.md", "operator_doc", "Obsidian export privacy and second-brain note guide."),
    ("docs/notebooklm-bridge.md", "operator_doc", "NotebookLM-style manual bridge contract."),
    ("docs/plugin-sdk.md", "operator_doc", "Plugin SDK hook, capability, and validation contract."),
    ("docs/plugin-registry.md", "operator_doc", "Plugin registry digest and local trust policy."),
    ("docs/plugins.md", "operator_doc", "Plugin examples, manifest, quarantine, and sample install guide."),
    ("docs/kimi-agent-gateway.md", "operator_doc", "Kimi-compatible HTTP Agent gateway guide."),
    ("docs/use-with-kimi.md", "operator_doc", "Kimi usage modes for copy-only, HTTP tools, and local Agent gateway."),
    ("docs/skill-mode.md", "operator_doc", "Zero-key Skill Mode CLI and local Agent gateway first-run guide."),
    ("docs/operator-drill.md", "operator_doc", "External platform operator drill and transcript guide."),
    ("docs/self-hosting.md", "operator_doc", "Docker/Skill Mode self-hosting guide."),
    ("docs/security.md", "operator_doc", "Local-first security model and recovery hardening guide."),
    ("docs/commercial-readiness.md", "operator_doc", "Commercial readiness contract, hosted-service boundaries, and local-first launch limits."),
    ("docs/adoption-telemetry.md", "operator_doc", "Local aggregate adoption telemetry and PMF readiness privacy contract."),
    ("docs/ecosystem-submission.md", "operator_doc", "Ecosystem submission metadata, verification, and no-frontend launch guide."),
    ("docs/support-desk.md", "operator_doc", "GitHub-first support desk, support bundle, and maintainer triage playbook."),
    ("docs/adopter-onboarding.md", "operator_doc", "First external adopter walkthrough and failure fallback guide."),
    ("docs/maintainer-rotation.md", "operator_doc", "Maintainer SLA labels, release blocker handling, and rotation checklist."),
    ("docs/public-support-status.md", "operator_doc", "Public support status and maintainer dashboard publishing guide."),
    ("docs/adopter-evidence-archive.md", "operator_doc", "External adopter evidence archive and maintainer handoff guide."),
    ("docs/published-image-evidence.md", "operator_doc", "Published-image evidence and pull-timeout fallback classification guide."),
    ("docs/release-asset-adoption.md", "operator_doc", "GitHub Release asset adoption replay guide."),
    ("docs/release-asset-bootstrap.md", "operator_doc", "GitHub Release asset bootstrap entrypoint for external platform Agents."),
    ("docs/release-cleanroom-bootstrap.md", "operator_doc", "Release-only cleanroom bootloader guide for repo-free external adoption."),
    ("docs/release-checklist.md", "operator_doc", "Release gate checklist for platform adoption evidence."),
    ("docs/roadmap.md", "operator_doc", "Roadmap and release track for platform adoption goals."),
    ("docs/agent-eval.md", "operator_doc", "Agent and retrieval eval guide."),
    ("docs/eval-frameworks.md", "operator_doc", "External eval framework selection, adapter boundary, and marketplace harness guide."),
    ("docs/api.md", "operator_doc", "HTTP API reference for platform workspaces."),
    ("docs/release-notes/v0.3.29-alpha.md", "release_doc", "Release notes for this adoption pack."),
    ("evals/README.md", "eval", "External eval overview and native/optional adapter guide."),
    ("platform/study-anything-platform-tools.json", "tool_manifest", "Source platform tool contract."),
    ("platform/ecosystem-submission.json", "submission_manifest", "Machine-readable ecosystem submission metadata."),
    ("platform/generated/study-anything-platform-openapi.json", "tool_import", "OpenAPI 3.1 import asset."),
    ("platform/generated/study-anything-openai-tools.json", "tool_import", "OpenAI-compatible function tools."),
    ("platform/generated/study-anything-tool-catalog.md", "tool_catalog", "Human-readable platform tool catalog."),
    ("platform/generated/study-anything-operator-drill-transcript.json", "submission_report", "External platform operator drill transcript."),
    ("platform/generated/study-anything-platform-submission-dry-run.json", "submission_report", "External platform submission dry-run readiness report."),
    ("platform/generated/study-anything-platform-manual-submission-rehearsal.json", "submission_report", "Manual platform-submission rehearsal and redacted handoff report."),
    ("platform/generated/study-anything-first-lesson-authoring-kit.json", "submission_report", "Copyable first-run lesson authoring kit for platform Agents."),
    ("platform/generated/study-anything-external-eval-harness.json", "submission_report", "Marketplace-quality external Agent eval harness for platform submissions."),
    ("platform/generated/study-anything-agent-eval-marketplace-enforcement.json", "submission_report", "Agent eval marketplace enforcement report for optional and required external judge gates."),
    ("platform/generated/study-anything-platform-adoption-feedback-diagnostics.json", "submission_report", "Platform import diagnostics and redacted feedback boundary report."),
    ("platform/generated/study-anything-platform-feedback-package.json", "feedback_package", "Local-only redacted feedback package manifest."),
    ("platform/generated/study-anything-platform-feedback-package.zip", "feedback_package", "Local-only redacted feedback package archive."),
    ("platform/generated/study-anything-platform-field-rehearsal.json", "submission_report", "Redacted field-adoption rehearsal transcript and import quirks report."),
    ("platform/generated/study-anything-platform-support-triage.json", "submission_report", "GitHub-first support triage report for external platform adoption failures."),
    ("platform/generated/study-anything-platform-support-bundle-replay.json", "submission_report", "Maintainer support bundle replay evidence and issue-to-fix classification report."),
    ("platform/generated/study-anything-platform-onboarding-readiness.json", "submission_report", "First-adopter onboarding readiness and maintainer SLA report."),
    ("platform/generated/study-anything-platform-triage-dashboard.json", "submission_report", "Generated platform triage dashboard JSON."),
    ("platform/generated/study-anything-platform-triage-dashboard.md", "submission_report", "Generated platform triage dashboard Markdown."),
    ("platform/generated/study-anything-public-support-status.json", "submission_report", "Public support status report."),
    ("platform/generated/study-anything-public-maintainer-dashboard.json", "submission_report", "Public maintainer dashboard JSON."),
    ("platform/generated/study-anything-public-maintainer-dashboard.md", "submission_report", "Public maintainer dashboard Markdown."),
    ("platform/generated/study-anything-published-image-evidence.json", "submission_report", "Published-image evidence JSON."),
    ("platform/generated/study-anything-published-image-evidence.md", "submission_report", "Published-image evidence Markdown."),
    ("platform/generated/study-anything-published-image-evidence.zip", "submission_report", "Published-image evidence package."),
    ("platform/generated/study-anything-published-image-evidence.sha256", "submission_report", "Published-image evidence checksum."),
    ("platform/generated/study-anything-release-asset-adoption.json", "submission_report", "GitHub Release asset adoption replay evidence JSON."),
    ("platform/generated/study-anything-release-asset-adoption.md", "submission_report", "GitHub Release asset adoption replay evidence Markdown."),
    ("platform/generated/study-anything-release-asset-adoption.zip", "submission_report", "GitHub Release asset adoption replay evidence package."),
    ("platform/generated/study-anything-release-asset-adoption.sha256", "submission_report", "GitHub Release asset adoption replay evidence checksum."),
    ("platform/generated/study-anything-release-asset-bootstrap.json", "submission_report", "GitHub Release asset bootstrap evidence JSON."),
    ("platform/generated/study-anything-release-asset-bootstrap.md", "submission_report", "GitHub Release asset bootstrap evidence Markdown."),
    ("platform/generated/study-anything-release-asset-bootstrap.zip", "submission_report", "GitHub Release asset bootstrap evidence package."),
    ("platform/generated/study-anything-release-asset-bootstrap.sha256", "submission_report", "GitHub Release asset bootstrap evidence checksum."),
    ("platform/generated/study-anything-release-cleanroom-bootstrap.json", "submission_report", "Release-only cleanroom bootstrap evidence JSON."),
    ("platform/generated/study-anything-release-cleanroom-bootstrap.md", "submission_report", "Release-only cleanroom bootstrap evidence Markdown."),
    ("platform/generated/study-anything-release-cleanroom-bootstrap.zip", "submission_report", "Release-only cleanroom bootstrap evidence package."),
    ("platform/generated/study-anything-release-cleanroom-bootstrap.sha256", "submission_report", "Release-only cleanroom bootstrap evidence checksum."),
    ("platform/generated/study-anything-platform-agent-replay.json", "submission_report", "Platform Agent release replay evidence JSON."),
    ("platform/generated/study-anything-platform-agent-replay.md", "submission_report", "Platform Agent release replay evidence Markdown."),
    ("platform/generated/study-anything-platform-agent-replay.zip", "submission_report", "Platform Agent release replay evidence package."),
    ("platform/generated/study-anything-platform-agent-replay.sha256", "submission_report", "Platform Agent release replay evidence checksum."),
    ("platform/generated/study-anything-adopter-evidence-archive.json", "submission_report", "External adopter evidence archive JSON."),
    ("platform/generated/study-anything-adopter-evidence-archive.md", "submission_report", "External adopter evidence archive Markdown."),
    ("platform/generated/study-anything-adopter-evidence-archive.zip", "submission_report", "External adopter evidence archive package."),
    ("platform/generated/study-anything-adopter-evidence-archive.sha256", "submission_report", "External adopter evidence archive checksum."),
    ("fixtures/platform-import-failures/schema_mismatch.json", "fixture", "Mock platform import failure fixture for schema mismatch."),
    ("fixtures/platform-import-failures/missing_local_gateway.json", "fixture", "Mock platform import failure fixture for missing local gateway."),
    ("fixtures/platform-import-failures/unsupported_auth_mode.json", "fixture", "Mock platform import failure fixture for unsupported auth mode."),
    ("fixtures/platform-import-failures/tool_naming_drift.json", "fixture", "Mock platform import failure fixture for tool naming drift."),
    ("fixtures/platform-import-failures/timeout.json", "fixture", "Mock platform import failure fixture for timeout diagnostics."),
    ("fixtures/platform-import-failures/cors_localhost.json", "fixture", "Mock platform import failure fixture for browser localhost restrictions."),
    ("fixtures/platform-import-failures/package_corruption.json", "fixture", "Mock platform import failure fixture for corrupted adoption packages."),
    ("fixtures/platform-import-failures/version_drift.json", "fixture", "Mock platform import failure fixture for version drift."),
    (".github/ISSUE_TEMPLATE/platform_import_failure.md", "support_template", "GitHub issue template for platform import failures."),
    (".github/ISSUE_TEMPLATE/local_gateway_failure.md", "support_template", "GitHub issue template for local Agent gateway failures."),
    (".github/ISSUE_TEMPLATE/published_image_pull_failure.md", "support_template", "GitHub issue template for published-image pull failures."),
    (".github/ISSUE_TEMPLATE/agent_eval_evidence_failure.md", "support_template", "GitHub issue template for Agent eval evidence failures."),
    (".github/ISSUE_TEMPLATE/docs_confusion.md", "support_template", "GitHub issue template for docs confusion reports."),
    ("fixtures/platform-support-tickets/platform_import_failure.json", "support_fixture", "Mock support ticket fixture for platform import failure triage."),
    ("fixtures/platform-support-tickets/local_gateway_failure.json", "support_fixture", "Mock support ticket fixture for local Agent gateway triage."),
    ("fixtures/platform-support-tickets/published_image_pull_failure.json", "support_fixture", "Mock support ticket fixture for published-image pull triage."),
    ("fixtures/platform-support-tickets/agent_eval_evidence_failure.json", "support_fixture", "Mock support ticket fixture for Agent eval evidence triage."),
    ("fixtures/platform-support-tickets/docs_confusion.json", "support_fixture", "Mock support ticket fixture for docs confusion triage."),
    ("fixtures/platform-support-bundles/local-ghcr-pull-timeout.json", "support_fixture", "Redacted support bundle fixture for local GHCR pull timeout replay."),
    ("fixtures/platform-support-bundles/cleanroom-runtime-launch-failed.json", "support_fixture", "Redacted support bundle fixture for cleanroom runtime launch replay."),
    ("fixtures/platform-support-bundles/privacy-contract-violation.json", "support_fixture", "Unsafe support bundle fixture used to prove privacy blocking."),
    ("fixtures/platform-release-blockers/tool_import_blocker.json", "release_blocker_fixture", "Mock release blocker fixture for platform tool import failures."),
    ("fixtures/platform-release-blockers/local_gateway_blocker.json", "release_blocker_fixture", "Mock release blocker fixture for local Agent gateway failures."),
    ("fixtures/platform-release-blockers/published_image_blocker.json", "release_blocker_fixture", "Mock release blocker fixture for published-image launch failures."),
    ("fixtures/platform-release-blockers/agent_eval_blocker.json", "release_blocker_fixture", "Mock release blocker fixture for Agent eval evidence failures."),
    ("fixtures/platform-release-blockers/support_bundle_privacy_blocker.json", "release_blocker_fixture", "Mock release blocker fixture for unsafe support bundle privacy reports."),
    ("fixtures/platform-status-links/intake.json", "status_linkage_fixture", "Public status linkage fixture for intake issues."),
    ("fixtures/platform-status-links/needs-repro.json", "status_linkage_fixture", "Public status linkage fixture for needs-repro issues."),
    ("fixtures/platform-status-links/confirmed.json", "status_linkage_fixture", "Public status linkage fixture for confirmed issues."),
    ("fixtures/platform-status-links/blocked-by-platform.json", "status_linkage_fixture", "Public status linkage fixture for blocked-by-platform issues."),
    ("fixtures/platform-status-links/docs-fix.json", "status_linkage_fixture", "Public status linkage fixture for docs-fix issues."),
    ("fixtures/platform-status-links/release-blocker.json", "status_linkage_fixture", "Public status linkage fixture for release-blocker issues."),
    ("fixtures/platform-status-links/resolved.json", "status_linkage_fixture", "Public status linkage fixture for resolved issues."),
    ("fixtures/adopter-evidence-archive/successful-release.json", "adopter_evidence_fixture", "Public evidence fixture for a successful release handoff."),
    ("fixtures/adopter-evidence-archive/local-ghcr-pull-timeout.json", "adopter_evidence_fixture", "Public evidence fixture for local GHCR pull timeout fallback."),
    ("fixtures/adopter-evidence-archive/needs-repro-issue.json", "adopter_evidence_fixture", "Public evidence fixture for needs-repro support state."),
    ("fixtures/adopter-evidence-archive/release-blocker.json", "adopter_evidence_fixture", "Public evidence fixture for release-blocker support state."),
    ("fixtures/adopter-evidence-archive/platform-blocked.json", "adopter_evidence_fixture", "Public evidence fixture for platform-blocked support state."),
    ("fixtures/adopter-evidence-archive/resolved-support-case.json", "adopter_evidence_fixture", "Public evidence fixture for resolved support state."),
    ("fixtures/published-image-evidence/manifest-pass-local-pull-timeout.json", "published_image_evidence_fixture", "Published-image evidence fixture for local pull timeout fallback."),
    ("fixtures/published-image-evidence/cached-image-missing.json", "published_image_evidence_fixture", "Published-image evidence fixture for cached-only local image misses."),
    ("fixtures/published-image-evidence/compose-up-timeout.json", "published_image_evidence_fixture", "Published-image evidence fixture for bounded Compose startup timeouts."),
    ("fixtures/published-image-evidence/manifest-only-runtime-unverified.json", "published_image_evidence_fixture", "Published-image evidence fixture for manifest-only runtime-unverified handoff."),
    ("fixtures/published-image-evidence/manifest-missing-platform.json", "published_image_evidence_fixture", "Published-image evidence fixture for a missing manifest platform."),
    ("fixtures/published-image-evidence/docker-images-failed.json", "published_image_evidence_fixture", "Published-image evidence fixture for failed docker-images publishing."),
    ("fixtures/published-image-evidence/ghcr-unavailable.json", "published_image_evidence_fixture", "Published-image evidence fixture for GHCR or network unavailability."),
    ("fixtures/published-image-evidence/remote-smoke-pass.json", "published_image_evidence_fixture", "Published-image evidence fixture for a passing remote smoke replay."),
    ("fixtures/published-image-evidence/remote-smoke-failed.json", "published_image_evidence_fixture", "Published-image evidence fixture for runtime smoke failure."),
    ("fixtures/release-asset-adoption/asset-only-pass.json", "release_asset_adoption_fixture", "Release asset adoption fixture for a passing asset-only replay."),
    ("fixtures/release-asset-adoption/asset-missing.json", "release_asset_adoption_fixture", "Release asset adoption fixture for a missing release asset."),
    ("fixtures/release-asset-adoption/digest-mismatch.json", "release_asset_adoption_fixture", "Release asset adoption fixture for digest mismatch."),
    ("fixtures/release-asset-adoption/pack-corrupted.json", "release_asset_adoption_fixture", "Release asset adoption fixture for a corrupted adoption pack."),
    ("fixtures/release-asset-adoption/published-evidence-missing.json", "release_asset_adoption_fixture", "Release asset adoption fixture for missing published-image evidence."),
    ("fixtures/release-asset-adoption/network-unavailable.json", "release_asset_adoption_fixture", "Release asset adoption fixture for GitHub release network unavailability."),
    ("platform/generated/study-anything-plugin-ecosystem-adoption-kit.json", "submission_report", "Copy-ready plugin ecosystem adoption kit for platform submissions."),
    ("platform/generated/study-anything-deployment-hardening.json", "submission_report", "Deployment hardening and clean-clone operator path report."),
    ("platform/generated/study-anything-learning-enrichment-bridge.json", "submission_report", "Learning Enrichment operator bridge report for platform Agents, NotebookLM, Obsidian, and second-brain handoff."),
    ("platform/packs/README.md", "platform_pack", "Platform pack index."),
    ("platform/packs/kimi/README.md", "platform_pack", "Kimi Work and Kimi-compatible setup."),
    ("platform/packs/kimi/pack.json", "platform_pack", "Machine-readable Kimi pack."),
    ("platform/packs/codex/README.md", "platform_pack", "Codex setup and command flow."),
    ("platform/packs/codex/pack.json", "platform_pack", "Machine-readable Codex pack."),
    ("platform/packs/workbuddy/README.md", "platform_pack", "WorkBuddy-style HTTP workspace setup."),
    ("platform/packs/workbuddy/pack.json", "platform_pack", "Machine-readable WorkBuddy pack."),
    ("skills/study-anything/SKILL.md", "skill", "Codex Skill entrypoint."),
    ("skills/study-anything/agents/openai.yaml", "skill", "OpenAI-compatible Skill agent metadata."),
    ("scripts/openai_compatible_agent_gateway.py", "gateway", "User-owned local HTTP Agent gateway."),
    ("scripts/mock_http_agent.py", "gateway", "Deterministic mock HTTP Agent for smoke tests."),
    ("scripts/setup_env.py", "runtime", "Generate local .env files with development-safe local secrets."),
    ("scripts/check_env.py", "runtime", "Validate required local environment variables before launch."),
    ("scripts/verify_api_smoke.sh", "verification", "Minimal API health/system/plugin smoke that follows .env API_PORT."),
    ("scripts/doctor.sh", "diagnostics", "Self-host doctor for Docker, ports, env, and Compose config."),
    ("scripts/launch_self_host.sh", "runtime", "Docker Compose self-host launcher."),
    ("scripts/stop_self_host.sh", "runtime", "Docker Compose self-host stop helper."),
    ("scripts/self_host_data.py", "runtime", "Backup and restore helper for self-hosted deployments."),
    ("scripts/verify_published_image_launch.py", "verification", "Disposable GHCR published-image launch verifier."),
    ("scripts/verify_backup_restore_drill.py", "verification", "Disposable backup and restore drill verifier."),
    ("scripts/verify_full_api_flow.py", "verification", "Full public API learning-loop smoke verifier used by published-image checks."),
    ("scripts/release_check.sh", "verification", "Strict release gate with automatic localhost-blocked report collection."),
    ("START_HERE.command", "runtime", "macOS double-click one-key beginner launcher."),
    ("scripts/start_here.sh", "runtime", "Beginner launcher for zero-key demo, persistent Skill Mode, Docker, and diagnostics."),
    ("scripts/launch_skill_mode.sh", "runtime", "Local Skill Mode API launcher."),
    ("scripts/stop_skill_mode.sh", "runtime", "Local Skill Mode API stop helper."),
    ("scripts/run_skill_mode_demo.sh", "verification", "One-command Skill Mode demo and eval gate."),
    ("scripts/study_anything_cli.py", "cli", "CLI for learning loop and evidence commands."),
    ("scripts/localhost_diagnostics.py", "diagnostics", "Shared localhost socket diagnostics for platform verifiers."),
    ("scripts/install_local_plugin.py", "cli", "CLI for explicit local plugin quarantine and approved install."),
    ("scripts/verify_external_adoption.py", "verification", "Adoption-proof-v1 verifier for external operators."),
    ("scripts/verify_clean_clone_adoption.py", "verification", "Disposable clean-clone Skill Mode and gateway adoption verifier."),
    ("scripts/verify_adoption_telemetry.py", "verification", "Aggregate adoption telemetry and PMF readiness verifier."),
    ("scripts/verify_agent_gateway_hardening.py", "verification", "User-owned Agent gateway hardening and privacy verifier."),
    ("scripts/verify_external_agent_adapter_hardening.py", "verification", "External Agent eval adapter hardening and bad-output diagnostics verifier."),
    ("scripts/verify_notebooklm_obsidian_bridge_hardening.py", "verification", "NotebookLM, Obsidian, and Learning Enrichment bridge privacy verifier."),
    ("scripts/verify_plugin_quarantine.py", "verification", "Plugin trust quarantine and explicit approval verifier."),
    ("scripts/verify_security_recovery_hardening.py", "verification", "Security recovery, backup manifest, and sync restore privacy verifier."),
    ("scripts/verify_platform_submission_dry_run.py", "verification", "External platform submission dry-run verifier."),
    ("scripts/generate_platform_adoption_pack.py", "diagnostics", "Generate or check the distributable platform adoption pack."),
    ("scripts/verify_platform_manual_submission_rehearsal.py", "verification", "Manual platform-submission rehearsal verifier."),
    ("scripts/verify_first_lesson_authoring_kit.py", "verification", "Copyable first-run lesson authoring kit verifier."),
    ("scripts/verify_external_eval_marketplace_harness.py", "verification", "Marketplace-quality external Agent eval harness verifier."),
    ("scripts/verify_agent_eval_marketplace_enforcement.py", "verification", "Agent eval marketplace enforcement verifier."),
    ("scripts/verify_platform_adoption_feedback_diagnostics.py", "verification", "Platform import diagnostics and feedback boundary verifier."),
    ("scripts/generate_platform_feedback_package.py", "diagnostics", "Generate a local-only redacted platform feedback package."),
    ("scripts/generate_platform_field_rehearsal.py", "diagnostics", "Generate redacted field-adoption rehearsal transcripts and failed-import fixtures."),
    ("scripts/verify_platform_field_rehearsal.py", "verification", "Verify field-adoption rehearsals, import quirks, failed-import fixtures, and pack inclusion."),
    ("scripts/generate_platform_support_triage.py", "diagnostics", "Generate GitHub-first issue templates, support ticket fixtures, and support triage report."),
    ("scripts/verify_platform_support_triage.py", "verification", "Verify support triage redaction, actionability, pack inclusion, and docs."),
    ("scripts/replay_support_bundle.py", "diagnostics", "Replay a redacted support bundle into maintainer classification and issue body."),
    ("scripts/generate_platform_support_bundle_replay.py", "diagnostics", "Generate support bundle replay evidence and fixtures."),
    ("scripts/verify_platform_support_bundle_replay.py", "verification", "Verify support bundle replay, privacy blocking, fixtures, and pack inclusion."),
    ("scripts/generate_platform_onboarding_readiness.py", "diagnostics", "Generate first-adopter onboarding, triage dashboard, and release-blocker fixtures."),
    ("scripts/verify_platform_onboarding_readiness.py", "verification", "Verify onboarding readiness, SLA labels, dashboard, release blockers, packs, submission, and docs."),
    ("scripts/generate_platform_public_support_status.py", "diagnostics", "Generate public support status, maintainer dashboard, and status-linkage fixtures."),
    ("scripts/verify_platform_public_support_status.py", "verification", "Verify public support status, dashboard, status-linkage fixtures, packs, submission, and docs."),
    ("scripts/generate_published_image_evidence.py", "diagnostics", "Generate published-image evidence, checksum, and release fallback fixtures."),
    ("scripts/verify_published_image_evidence.py", "verification", "Verify published-image evidence, fixtures, platform packs, submission, adoption pack, and docs."),
    ("scripts/generate_release_asset_adoption.py", "diagnostics", "Generate GitHub Release asset adoption replay evidence and fixtures."),
    ("scripts/verify_release_asset_adoption.py", "verification", "Verify GitHub Release asset download, digest, pack, evidence, and runtime replay."),
    ("scripts/bootstrap_from_release.py", "verification", "Bootstrap external platform adoption from public GitHub Release assets."),
    ("scripts/generate_release_asset_bootstrap.py", "diagnostics", "Generate GitHub Release asset bootstrap evidence."),
    ("platform/bootstrap/study_anything_release_bootstrap.py", "verification", "Standalone release-only cleanroom bootstrapper."),
    ("scripts/generate_release_cleanroom_bootstrap.py", "diagnostics", "Generate release-only cleanroom bootstrap evidence."),
    ("scripts/replay_platform_agent_from_release.py", "verification", "Replay platform Agent tool calls from public GitHub Release assets."),
    ("scripts/generate_platform_agent_replay.py", "diagnostics", "Generate platform Agent release replay evidence."),
    ("scripts/generate_adopter_evidence_archive.py", "diagnostics", "Generate external adopter evidence archive, checksum, and maintainer handoff fixtures."),
    ("scripts/verify_adopter_evidence_archive.py", "verification", "Verify adopter evidence archive, fixtures, platform packs, submission, adoption pack, and docs."),
    ("scripts/verify_plugin_ecosystem_adoption_kit.py", "verification", "Plugin ecosystem sample, registry, and trust-policy adoption verifier."),
    ("scripts/verify_deployment_hardening.py", "verification", "Deployment hardening and published-image operator path verifier."),
    ("scripts/verify_learning_enrichment_bridge.py", "verification", "Learning Enrichment operator bridge verifier."),
    ("scripts/verify_ecosystem_submission_pack.py", "verification", "Ecosystem submission pack verifier for external platform review."),
    ("scripts/verify_platform_operator_drill.py", "verification", "External platform pack consumption verifier."),
    ("scripts/verify_platform_agent_tools.py", "verification", "Platform tool manifest runtime verifier."),
    ("scripts/verify_platform_ecosystem_eval_flow.py", "verification", "Full platform ecosystem learning/eval/export verifier."),
    ("scripts/verify_importer_lesson_flow.py", "verification", "NotebookLM-style importer lesson verifier."),
    ("scripts/verify_importer_runtime_retrieval_flow.py", "verification", "Importer runtime plus retrieval verifier."),
    ("scripts/verify_falkordb_flow.py", "verification", "Optional FalkorDB topology projection API verifier."),
    ("scripts/verify_platform_lesson_flow.py", "verification", "Enriched platform lesson verifier."),
    ("scripts/verify_mock_http_agent_flow.py", "verification", "User-owned mock HTTP Agent learning-loop smoke verifier."),
    ("scripts/verify_agent_eval_flow.py", "verification", "Agent eval artifact verifier."),
    ("scripts/verify_agent_eval_assets.py", "verification", "Agent eval asset and adapter contract verifier."),
    ("scripts/verify_agent_eval_baseline.py", "verification", "Agent eval baseline and regression gate verifier."),
    ("scripts/run_external_agent_evals.py", "verification", "Promptfoo/DeepEval/retrieval eval runner."),
    ("scripts/verify_openai_compatible_gateway.py", "verification", "OpenAI-compatible gateway dry-run verifier."),
    ("scripts/verify_skill_cli_flow.py", "verification", "Skill Mode CLI learning-loop verifier with actionable recovery output."),
    ("infra/compose/docker-compose.yml", "runtime", "Docker Compose source-build stack definition."),
    ("infra/compose/docker-compose.images.yml", "runtime", "Docker Compose published-image override."),
    ("scripts/diagnose_adoption.py", "diagnostics", "Adoption diagnostics and remediation hints."),
    ("evals/promptfoo/agent-eval-artifact.yaml", "eval", "Promptfoo eval config."),
    ("evals/deepeval/study_anything_quality_eval.py", "eval", "DeepEval-compatible native quality adapter."),
    ("evals/baselines/study-anything-agent-eval-baseline.json", "eval", "Deterministic Agent eval regression baseline."),
    ("evals/fixtures/fake-agent-learning-loop.json", "eval_fixture", "Fake deterministic Agent eval fixture."),
    ("evals/fixtures/mock-http-agent-learning-loop.json", "eval_fixture", "Mock HTTP/user-owned Agent eval fixture."),
    ("fixtures/notebooklm/README.md", "fixture", "NotebookLM fixture notes."),
    ("fixtures/notebooklm/notebooklm-style-context-package.json", "fixture", "NotebookLM-style context package fixture."),
    ("plugins/registry.json", "plugin_registry", "Bundled sample plugin registry with source digests."),
    ("plugins/example-note-importer/plugin.json", "sample_plugin", "Markdown and Obsidian importer manifest."),
    ("plugins/example-note-importer/plugin.py", "sample_plugin", "Markdown and Obsidian importer template source."),
    ("plugins/example-web-importer/plugin.json", "sample_plugin", "Web excerpt importer manifest."),
    ("plugins/example-web-importer/plugin.py", "sample_plugin", "Web excerpt importer template source."),
    ("plugins/example-enrichment-importer/plugin.json", "sample_plugin", "Learning enrichment importer manifest."),
    ("plugins/example-enrichment-importer/plugin.py", "sample_plugin", "Learning enrichment importer template source."),
    ("plugins/example-exporter/plugin.json", "sample_plugin", "Obsidian and second-brain exporter manifest."),
    ("plugins/example-exporter/plugin.py", "sample_plugin", "Obsidian and second-brain exporter template source."),
    ("plugins/example-agent-provider/plugin.json", "sample_plugin", "User-owned Agent provider manifest template."),
    ("plugins/example-agent-provider/plugin.py", "sample_plugin", "User-owned Agent provider template source."),
]

REQUIRED_PLATFORM_TOOLS = [
    "study_anything_deployment_guide",
    "study_anything_commercial_readiness",
    "study_anything_adoption_telemetry",
    "study_anything_pmf_readiness",
    "study_anything_health",
    "study_anything_eval_policy",
    "study_anything_create_session",
    "study_anything_add_reading",
    "study_anything_validate_context_package",
    "study_anything_create_session_from_context_package",
    "study_anything_append_context_package",
    "study_anything_plugin_sdk",
    "study_anything_plugin_capabilities",
    "study_anything_validate_plugin_package",
    "study_anything_run_importer",
    "study_anything_add_enrichment",
    "study_anything_run",
    "study_anything_answer",
    "study_anything_mastery",
    "study_anything_retrieval_search",
    "study_anything_retrieval_quality_eval",
    "study_anything_teaching_layers",
    "study_anything_agent_audit",
    "study_anything_agent_eval_artifact",
    "study_anything_agent_quality_eval",
    "study_anything_agent_eval_report",
    "study_anything_obsidian_export",
    "study_anything_enrichment_artifact_export",
    "study_anything_learning_package_export",
    "study_anything_second_brain_handoff_export",
]


class AdoptionPackError(RuntimeError):
    """Readable adoption-pack generation failure."""


def format_cli_failure(exc: BaseException) -> str:
    diagnostic = redact_diagnostic(str(exc))
    return "\n".join(
        [
            f"generate_platform_adoption_pack failed: {diagnostic}",
            "",
            "Next steps:",
            "1. Rebuild the adoption pack: python3 scripts/generate_platform_adoption_pack.py",
            "2. Re-check the adoption pack: python3 scripts/generate_platform_adoption_pack.py --check",
            "3. Re-check the platform bundle manifest: python3 scripts/generate_platform_bundle_manifest.py --check",
            "4. Run the external adoption verifier: python3 scripts/verify_external_adoption.py --pack platform/generated/study-anything-platform-adoption-pack.zip --current-worktree",
        ]
    )


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise AdoptionPackError(f"Cannot read JSON {path.relative_to(ROOT)}: {exc}") from exc


def assert_safe_path(relative_path: str) -> Path:
    path = ROOT / relative_path
    if not path.exists():
        raise AdoptionPackError(f"Adoption pack file is missing: {relative_path}")
    if path.is_dir():
        raise AdoptionPackError(f"Adoption pack file must not be a directory: {relative_path}")
    if any(part in {".git", ".env", ".venv", "data", "__pycache__"} for part in path.parts):
        raise AdoptionPackError(f"Unsafe adoption pack path: {relative_path}")
    return path


def file_record(relative_path: str, kind: str, purpose: str) -> dict[str, object]:
    path = assert_safe_path(relative_path)
    return {
        "path": relative_path,
        "archive_path": f"{ARCHIVE_ROOT}/{relative_path}",
        "kind": kind,
        "purpose": purpose,
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def validate_source_contract() -> None:
    tools = read_json(ROOT / "platform" / "study-anything-platform-tools.json")
    if tools.get("schema_version") != "study-anything-platform-tools-v1":
        raise AdoptionPackError("Platform tool manifest schema drifted.")
    names = {tool.get("name") for tool in tools.get("tools", [])}
    missing = [name for name in REQUIRED_PLATFORM_TOOLS if name not in names]
    if missing:
        raise AdoptionPackError(f"Platform tool manifest is missing adoption tools: {missing}")


def pack_readme() -> str:
    return """# Study Anything Platform Adoption Pack

This archive is the copy-ready integration bundle for Kimi Work, Codex,
WorkBuddy-style HTTP tool workspaces, and other platform Agents.

Use it when the platform Agent owns browsing, files, video slicing, outside
tools, real model credentials, and conversation. Study Anything owns the
source-bound learning workflow, state, audit, eval evidence, retrieval quality,
and Obsidian/NotebookLM handoff.

## Quick Start

1. Start Study Anything locally with Skill Mode or the published Docker image.
2. Import `platform/generated/study-anything-platform-openapi.json` or
   `platform/generated/study-anything-openai-tools.json` into your platform.
3. Follow the operator guide for your platform under `platform/packs/`.
4. Run:

```bash
python3 scripts/verify_external_adoption.py --pack platform/generated/study-anything-platform-adoption-pack.zip --copy-worktree
```

The verifier emits `adoption-proof-v1` JSON. Treat that JSON as the minimum
acceptance evidence before claiming an external platform integration works.
The generated `adopter-evidence-archive-v1` package is the public maintainer
handoff bundle for release proof, checksums, and local GHCR pull-timeout
fallback evidence.

## Verification Command Scopes

Each `platform/packs/*/pack.json` separates commands by where they can run:

- `local_verification_commands` are included in this adoption pack and are safe to run from the
  extracted pack root.
- `source_verification_commands` require a full source checkout. For example,
  `scripts/verify_commercial_readiness.py` imports the local API package and should not be run from
  this zip alone.

## Privacy

Do not put real model API keys in Study Anything. Keep real model credentials
inside the user's own Agent or platform runtime. The adoption evidence is
designed to be redacted and must not include raw source text, long answers,
agent endpoints with secrets, or platform-private browsing/video context.
"""


def manifest_payload() -> dict[str, object]:
    validate_source_contract()
    file_paths = [path for path, _kind, _purpose in PACK_FILES]
    if len(file_paths) != len(set(file_paths)):
        raise AdoptionPackError("Adoption pack file list contains duplicates.")
    recursive_outputs = sorted(SELF_REFERENTIAL_OUTPUTS.intersection(file_paths))
    if recursive_outputs:
        raise AdoptionPackError(
            "Adoption pack must not include generated manifest outputs that hash "
            f"the pack itself: {recursive_outputs}"
        )
    return {
        "schema_version": "study-anything-platform-adoption-pack-v1",
        "name": "study-anything-platform-adoption-pack",
        "version": "v0.3.29-alpha",
        "archive_name": ARCHIVE_PATH.name,
        "archive_root": ARCHIVE_ROOT,
        "description": (
            "Copy-ready platform adoption pack for Kimi Work, Codex, WorkBuddy-style "
            "HTTP workspaces, NotebookLM/Obsidian handoff, and external Agent eval proof."
        ),
        "supported_platforms": ["kimi-work", "codex", "workbuddy-style-http", "generic-http-tools"],
        "runtime_modes": ["skill-mode", "published-image"],
        "no_frontend_required": True,
        "real_model_keys_stored_by_study_anything": False,
        "required_tool_names": REQUIRED_PLATFORM_TOOLS,
        "acceptance": {
            "proof_schema": "adoption-proof-v1",
            "command": (
                "python3 scripts/verify_external_adoption.py --pack "
                "platform/generated/study-anything-platform-adoption-pack.zip --copy-worktree"
            ),
            "target_minutes": 15,
            "must_verify": [
                "archive sha256 manifest",
                "OpenAPI/OpenAI tool import assets",
                "Kimi/Codex/WorkBuddy operator packs",
                "Skill Mode or published-image runtime",
                "external platform Agent learning flow",
                "external platform pack consumption drill",
                "retrieval-quality-eval-v1",
                "agent-eval-policy-v1",
                "agent-eval-report-v1",
                "agent-quality-eval-v1",
                "study-anything-agent-eval-regression-report-v1",
                "obsidian-markdown-export-v1",
                "learning-package-v1",
                "second-brain-handoff-v1",
                "plugin-sdk-v1",
                "plugin-capability-index-v1",
                "plugin-package-validation-v1",
                "plugin-quarantine-verification-v1",
                "deployment-guide-v1",
                "commercial-readiness-v1",
                "adoption-telemetry-v1",
                "pmf-readiness-v1",
                "adoption-telemetry-verification-v1",
                "agent-gateway-hardening-verification-v1",
                "notebooklm-obsidian-bridge-hardening-v1",
                "learning-enrichment-bridge-verification-v1",
                "security-recovery-hardening-verification-v1",
                "platform-submission-dry-run-v1",
                "platform-manual-submission-rehearsal-v1",
                "first-run-lesson-authoring-kit-v1",
                "external-eval-marketplace-harness-v1",
                "agent-eval-marketplace-enforcement-v1",
                "platform-adoption-feedback-diagnostics-v1",
                "platform-feedback-package-v1",
                "platform-field-adoption-rehearsal-v1",
                "platform-import-failure-fixture-v1",
                "platform-support-triage-v1",
                "platform-support-ticket-fixture-v1",
                "platform-support-issue-template-v1",
                "platform-support-bundle-replay-evidence-v1",
                "platform-support-bundle-replay-v1",
                "platform-onboarding-readiness-v1",
                "first-external-adopter-walkthrough-v1",
                "maintainer-sla-labels-v1",
                "maintainer-rotation-checklist-v1",
                "platform-triage-dashboard-v1",
                "platform-release-blocker-fixture-v1",
                "public-support-status-v1",
                "public-maintainer-dashboard-v1",
                "public-status-linkage-fixture-v1",
                "published-image-evidence-v1",
                "published-image-evidence-fixture-v1",
                "release-asset-adoption-v1",
                "release-asset-adoption-fixture-v1",
                "release-asset-adoption-proof-v1",
                "release-asset-bootstrap-v1",
                "release-asset-bootstrap-transcript-v1",
                "platform-agent-release-replay-v1",
                "adopter-evidence-archive-v1",
                "adopter-evidence-fixture-v1",
                "plugin-ecosystem-adoption-kit-v1",
                "deployment-hardening-verification-v1",
                "ecosystem-submission-v1",
                "ecosystem-submission-verification-v1",
            ],
        },
        "privacy_contract": {
            "must_not_store": [
                "real model API keys",
                "platform private browser traces",
                "raw long source text in eval evidence",
                "raw answer text in eval evidence",
                "agent endpoint secrets",
            ],
            "user_owned_exports_may_include": [
                "learner answers",
                "review history",
                "Obsidian markdown selected by the learner",
            ],
        },
        "files": [file_record(*item) for item in PACK_FILES],
    }


def dump_json(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"


def archive_bytes(manifest: dict[str, object]) -> bytes:
    import io

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, content in [
            (f"{ARCHIVE_ROOT}/ADOPTION_PACK_README.md", pack_readme().encode("utf-8")),
            (f"{ARCHIVE_ROOT}/manifest.json", dump_json(manifest).encode("utf-8")),
        ]:
            info = zipfile.ZipInfo(name)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
        for record in sorted(manifest["files"], key=lambda item: str(item["path"])):  # type: ignore[index]
            relative_path = str(record["path"])
            source = ROOT / relative_path
            info = zipfile.ZipInfo(str(record["archive_path"]))
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, source.read_bytes())
    return buffer.getvalue()


def build_outputs() -> tuple[str, bytes]:
    archive_manifest = manifest_payload()
    archive = archive_bytes(archive_manifest)
    enriched = dict(archive_manifest)
    enriched["archive_sha256"] = sha256_bytes(archive)
    enriched["archive_bytes"] = len(archive)
    return dump_json(enriched), archive


def write_outputs() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    manifest_text, archive = build_outputs()
    MANIFEST_PATH.write_text(manifest_text, encoding="utf-8")
    ARCHIVE_PATH.write_bytes(archive)
    print(f"wrote {MANIFEST_PATH.relative_to(ROOT)}")
    print(f"wrote {ARCHIVE_PATH.relative_to(ROOT)}")


def check_outputs() -> None:
    expected_manifest, expected_archive = build_outputs()
    missing = [
        str(path.relative_to(ROOT))
        for path in [MANIFEST_PATH, ARCHIVE_PATH]
        if not path.exists()
    ]
    stale = []
    if MANIFEST_PATH.exists() and MANIFEST_PATH.read_text(encoding="utf-8") != expected_manifest:
        stale.append(str(MANIFEST_PATH.relative_to(ROOT)))
    if ARCHIVE_PATH.exists() and ARCHIVE_PATH.read_bytes() != expected_archive:
        stale.append(str(ARCHIVE_PATH.relative_to(ROOT)))
    if missing or stale:
        raise AdoptionPackError(
            "Platform adoption pack is stale. Run "
            "`python3 scripts/generate_platform_adoption_pack.py`. "
            f"missing={missing} stale={stale}"
        )
    print("ok    generated platform adoption pack is up to date")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    if args.check:
        check_outputs()
    else:
        write_outputs()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # pragma: no cover - CLI failure path
        print(format_cli_failure(exc), file=sys.stderr)
        sys.exit(1)
