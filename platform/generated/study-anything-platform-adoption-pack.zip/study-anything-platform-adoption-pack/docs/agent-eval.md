# Agent Eval Foundation

Study Anything separates Agent invocation audit from Agent quality evaluation.

- Invocation audit proves that required learning tasks were handled by a Study Anything Agent provider.
- Eval artifacts turn that audit into a redacted, tool-neutral record.
- Mature open-source eval projects then score quality, task completion, trajectory, and grounding.

This avoids a false sense of safety from a tiny homegrown judge while keeping the core self-host alpha
usable without cloud accounts, judge-model API keys, or a mandatory eval service.

## Current Public Surface

- `GET /v1/sessions/{session_id}/agent-audit`
- `GET /v1/evals/policy`
- `GET /v1/sessions/{session_id}/agent-eval/artifact`
- `GET /v1/sessions/{session_id}/agent-eval/quality`
- `GET /v1/sessions/{session_id}/agent-eval/report`
- `GET /v1/evals/quality/cases`
- `GET /v1/evals/retrieval/cases`
- `GET|POST /v1/sessions/{session_id}/retrieval/eval`
- `GET /v1/sessions/{session_id}/agent-eval` deprecated alias for invocation audit only

`agent-audit` proves which provider handled `quiz.generate`, `answer.grade`, and
`insight.synthesize`. `evals/policy` returns `agent-eval-policy-v1`: the machine-readable release
gate, optional external adapter rules, failure classes, fixture paths, and privacy contract.
`agent-eval/artifact` packages invocation proof for external eval tooling.
`agent-eval/quality` adds the first deterministic teaching-quality layer: overview, glossary,
quiz, grading, synthesis, grounding, enrichment readiness, and Obsidian readiness.
`agent-eval/report` returns `agent-eval-report-v1`: the per-session maturity report that combines
invocation proof, trajectory coverage, teaching quality, optional retrieval grounding, export
readiness, privacy redaction, and optional external adapter readiness.
`retrieval/eval` adds deterministic retrieval/context quality gates for source binding, snippet
minimality, query relevance, and Learning Context Package handoff validity.
`external-eval-marketplace-harness-v1` is the copyable submission contract that ties the native
release gates, optional mature adapters, fixtures, timeout policy, sample eval cases, and privacy
assertions together for Kimi, Codex, WorkBuddy-style, and generic OpenAPI platform Agents.

These eval endpoints are redacted. They do not return reading prose, source titles, answers, grading
feedback, insights, Agent endpoints, raw Agent metadata, API keys, retrieval snippets, or tool secrets.

## Eval Policy And Report

`agent-eval-policy-v1` is the stable rulebook for platform Agents and release scripts:

- native fast gate is required for release and does not need judge-model credentials
- Promptfoo, DeepEval, LangChain AgentEvals, and Ragas are optional external adapters unless an
  operator explicitly passes `--required`
- missing runtimes, missing judge credentials, and timeouts are reported as explainable `skipped`
  outcomes when the adapter is optional
- schema mismatches, failed native gates, and privacy leaks are failures
- fake deterministic and mock HTTP/user-owned Agent fixtures live under `evals/fixtures/`

`agent-eval-report-v1` is the per-session result that a Kimi/Codex/WorkBuddy-style platform Agent
should fetch after learning:

```bash
curl http://127.0.0.1:8000/v1/evals/policy
curl http://127.0.0.1:8000/v1/sessions/<session-id>/agent-eval/report
API_BASE=http://127.0.0.1:8000 \
  python3 scripts/run_external_agent_evals.py --tool report --create-session --required
python3 scripts/verify_external_eval_marketplace_harness.py --check
```

The report is not an LLM judge. It is the redacted release-gate summary that answers: did Study
Anything invoke its Agent workflow, did minimum teaching quality pass, are exports ready, are privacy
flags clean, and are external adapter datasets available?

For framework-by-framework boundaries, see `docs/eval-frameworks.md`.

## Agent Eval Marketplace Enforcement

`agent-eval-marketplace-enforcement-v1` is the release and ecosystem-submission gate for proving
that Study Anything eval evidence is actually enforceable by platform Agents. It keeps the native
fast gate required for release, while Promptfoo, DeepEval, LangChain AgentEvals, and Ragas remain
optional external judge integrations unless an operator explicitly runs them in required mode.

```bash
python3 scripts/verify_agent_eval_marketplace_enforcement.py --check
```

The verifier checks the external eval runner contract, timeout controls, malformed judge-output
diagnostics, missing-runtime behavior, baseline regression, platform-pack evidence, adoption-pack
inclusion, and privacy redaction. Optional external judge failures produce readable skipped evidence;
required external judge failures must exit non-zero so a marketplace submission cannot silently pass.
Judge/model credentials stay in the operator's Agent, CI environment, or external eval workspace.
Study Anything records provider/task evidence only and does not store judge API keys, model keys,
Agent endpoint secrets, raw source text, learner answers, or private browser/video context in the
shared report.

## Multi-Teacher Attribution

Study Anything supports layered teaching without requiring Study Anything itself to own real model
keys. A user-owned Agent can route different learning layers to different models or tools behind its
own gateway while Study Anything records only redacted provider/task evidence.

The public multi-teacher contract is:

| Learning layer | Agent task | Eval purpose |
| --- | --- | --- |
| Whole-topic explanation | `teach.overview` | Prove the learner received a source-bound overview. |
| Professional term explanation | `teach.glossary` | Prove terminology was explained separately from the overview. |
| Active recall | `quiz.generate` | Prove a source-bound practice item was generated. |
| Feedback loop | `answer.grade` | Prove grading produced a bounded score and feedback. |
| Transfer insight | `insight.synthesize` | Prove the session ended with a reusable synthesis. |

These five tasks are the native required task set for `agent-audit-v1`,
`agent-eval-artifact-v1`, and `agent-eval-policy-v1`. A session that skips
`teach.overview` or `teach.glossary` is intentionally partial for release-grade
multi-teacher evidence, even if quiz generation, grading, and synthesis ran.

Run the release gate directly with:

```bash
python3 scripts/verify_multiteacher_agent_eval_hardening.py
```

The verifier emits `multiteacher-agent-eval-hardening-v1`. It runs both a fake deterministic Agent
baseline and a mock user-owned HTTP Agent, then proves that every layer has `provider_id`,
`task_type`, `status`, `latency_ms`, optional `confidence`, and redacted metadata. The fake path must
report `used_fake_agent=true` and `used_external_agent=false`; the HTTP path must report
`used_external_agent=true` and `used_fake_agent=false`.

The verifier is intentionally not a pedagogy benchmark. It answers the operational question: did the
learning loop actually go through Study Anything's Agent contract, and can an external eval layer
trust the resulting trajectory without seeing raw source text, answers, Agent endpoints, real model
keys, judge keys, or private browser/video context?

## External Agent Adapter Hardening

Before treating a user-owned HTTP Agent as production-ready, run:

```bash
python3 scripts/verify_external_agent_adapter_hardening.py
```

The verifier emits `external-agent-adapter-hardening-v1`. It creates a mock-real HTTP Agent, proves
external Agent evidence is separated from fake deterministic evidence, and covers bad-output
diagnostics for malformed JSON, invalid status, missing content, invalid score, invalid confidence,
timeouts, missing citations, and missing declared capabilities. The report is redacted and must not
return source text, learner answers, Agent endpoints, real model keys, or secret-looking metadata
values.

## Open-Source Eval Selection

GitHub metadata was checked on 2026-06-12.

| Project | Stars | License | Use In Study Anything |
| --- | ---: | --- | --- |
| [Promptfoo](https://github.com/promptfoo/promptfoo) | ~22,200 | MIT | First CLI/CI adapter for HTTP contract checks, regression gates, and red-team assertions. |
| [DeepEval](https://github.com/confident-ai/deepeval) | ~16,100 | Apache-2.0 | Python eval harness for task completion, component-level metrics, and judge-model scoring. |
| [Ragas](https://github.com/explodinggradients/ragas) | ~14,400 | Apache-2.0 | Source grounding, answer relevance, context relevance, and citation-quality evaluation. |
| [LangChain AgentEvals](https://github.com/langchain-ai/agentevals) | ~617 | MIT | Trajectory matching for expected Agent/tool step order. |
| [Phoenix](https://github.com/Arize-ai/phoenix) | 10,021 | Other | Observability/eval candidate, useful later if Study Anything needs a heavier local eval UI. |
| [OpenAI Evals](https://github.com/openai/evals) | 18,627 | Other | Benchmark registry reference, not the first integration because license and workflow fit are weaker. |
| [AgentBench](https://github.com/THUDM/AgentBench) | 3,473 | Apache-2.0 | Academic benchmark reference, not a product smoke/eval harness. |

The first implementation path is:

1. Promptfoo for local HTTP and CI gates.
2. DeepEval for Python quality eval suites.
3. LangChain AgentEvals for trajectory scoring.
4. Ragas for source grounding once enrichment/retrieval datasets are exported.

## Native Gates

`agent-eval/artifact` currently includes deterministic gates that require no judge model:

- `agent_invocation_coverage`: all required learning tasks were observed.
- `source_reference_present`: the session has a source reference.
- `excerpt_hash_present`: source evidence is represented by a hash, not raw prose.
- `privacy_redaction`: audit/eval artifacts omit private learning content and Agent endpoints.
- `external_agent_used`: advisory gate showing whether a user-owned Agent was used instead of demo.

The first four gates must pass before external quality evals are meaningful.

## Promptfoo

Create or reuse a completed learning session, then run the Study Anything wrapper:

```bash
API_BASE=http://127.0.0.1:8000 \
  .venv/bin/python scripts/run_external_agent_evals.py --tool promptfoo --create-session
```

For release-candidate validation where Node/npm package installation is allowed to fail the build,
require the external gate:

```bash
API_BASE=http://127.0.0.1:8000 \
  .venv/bin/python scripts/run_external_agent_evals.py --tool promptfoo --create-session --required
```

The wrapper pins Promptfoo and applies a timeout. This avoids clean clones hanging silently on first
`npx` package download while still using the mature Promptfoo runner when the operator enables the
external gate.

For the full adoption smoke from a disposable clone:

```bash
python3 scripts/verify_clean_clone_adoption.py --repo . --with-promptfoo
```

When a sandbox blocks automatic localhost port probing, pin the disposable Skill Mode API and the
optional Promptfoo eval API separately:

```bash
python3 scripts/verify_clean_clone_adoption.py --repo . --with-promptfoo \
  --api-port 8012 --promptfoo-api-port 8013
```

If the output is `status=ok`, the Promptfoo path consumed the redacted artifact successfully. That is
still a contract/evidence gate, not a claim that the Agent's teaching quality is good.

You can also call Promptfoo directly:

```bash
npx promptfoo@0.121.15 eval -c evals/promptfoo/agent-eval-artifact.yaml \
  --var apiBase=http://127.0.0.1:8000 \
  --var sessionId=<completed-session-id>
```

The template calls `GET /v1/sessions/{session_id}/agent-eval/artifact` and asserts that the schema,
required gates, adapter matrix, and Agent trajectory are present.

## DeepEval

DeepEval is the preferred Python quality harness after the native gates pass. v0.2.18+ includes a
custom non-LLM metric adapter at:

```text
evals/deepeval/study_anything_quality_eval.py
```

Run it through the shared wrapper:

```bash
API_BASE=http://127.0.0.1:8000 \
  .venv/bin/python scripts/run_external_agent_evals.py \
  --tool deepeval \
  --create-session \
  --allow-native-quality-fallback
```

When `deepeval` is installed, the adapter uses DeepEval's custom metric interface against
`agent-eval/quality`. Without DeepEval, `--allow-native-quality-fallback` runs the same deterministic
quality report directly and labels the result `deepeval-compatible-native`. Do not treat fallback as
the same claim as a real DeepEval run.

Future judge-model metrics should include:

- `TaskCompletionMetric`: did the external Agent complete the learning task?
- `GEval`: Study Anything-specific rubric, such as source-bound learning usefulness.
- `AnswerRelevancy`: does feedback answer the learner's actual misunderstanding?
- `Faithfulness`: does generated synthesis remain grounded in the supplied source?

DeepEval can use multiple judge providers. Study Anything should never store the judge model key; the
operator configures judge credentials in their eval environment.

## LangChain AgentEvals

LangChain AgentEvals is the trajectory adapter. Study Anything already emits the canonical sequence:

1. `quiz.generate`
2. `answer.grade`
3. `insight.synthesize`

The exported `trajectory` field can be transformed into the expected message/tool-call shape for
`create_trajectory_match_evaluator`.

## Ragas

Ragas becomes important after Learning Enrichment Layer and LanceDB retrieval work. It should evaluate:

- faithfulness against selected source chunks
- answer relevance
- context relevance
- citation usefulness

Do not use Ragas as proof that the Agent was called. That remains `agent-audit`.

v0.2.21 adds a Ragas-compatible native retrieval gate. It is not a full Ragas run, but it gives Ragas
and judge-model pipelines a redacted, stable report to consume:

```bash
STUDY_ANYTHING_RETRIEVAL_BACKEND=memory API_BASE=http://127.0.0.1:8000 \
  python3 scripts/run_external_agent_evals.py --tool retrieval --create-session --required
```

The report schema is `retrieval-quality-eval-v1`. It includes result metadata, scores, source
references, excerpt hashes, and gate outcomes, but not raw source text or retrieval snippets.

## Regression Baseline

v0.2.24 adds a committed fast native baseline at:

```text
evals/baselines/study-anything-agent-eval-baseline.json
```

Generate or verify it with:

```bash
.venv/bin/python scripts/verify_agent_eval_baseline.py --write
.venv/bin/python scripts/verify_agent_eval_baseline.py --check
```

The check emits `study-anything-agent-eval-regression-report-v1`. It compares the current scorecard
against the committed baseline for:

- Promptfoo, DeepEval, LangChain AgentEvals, and Ragas adapter ids.
- `quiz.generate -> answer.grade -> insight.synthesize` trajectory coverage.
- required native eval gates.
- `agent-quality-eval-v1` teaching quality score.
- `retrieval-quality-eval-v1` retrieval/context quality score.
- privacy invariants for source text, answers, feedback, endpoints, metadata, and model/judge keys.

This is the default CI/release gate because it is deterministic and local-first. External eval tools
remain available through `scripts/run_external_agent_evals.py`, but they are only blocking when the
operator explicitly passes `--required` and accepts package install/network cost.

## Local Smoke

Against a running API:

```bash
API_BASE=http://127.0.0.1:8000 python3 scripts/verify_agent_eval_flow.py
python3 scripts/verify_agent_eval_baseline.py --check
API_BASE=http://127.0.0.1:8000 python3 scripts/run_external_agent_evals.py --tool report --create-session --required
API_BASE=http://127.0.0.1:8000 python3 scripts/run_external_agent_evals.py --tool deepeval --create-session --allow-native-quality-fallback
STUDY_ANYTHING_RETRIEVAL_BACKEND=memory API_BASE=http://127.0.0.1:8000 \
  python3 scripts/verify_platform_ecosystem_eval_flow.py
```

When checking a user-owned HTTP Agent path, set:

```bash
python3 scripts/mock_http_agent.py --host 127.0.0.1 --port 8787
EXPECT_EXTERNAL_AGENT=true API_BASE=http://127.0.0.1:8000 AGENT_ENDPOINT=http://127.0.0.1:8787/invoke \
  python3 scripts/verify_agent_eval_flow.py
```

This smoke verifies native gates and adapter readiness. It does not call judge models.

To prevent drift between the API artifact, Promptfoo config, docs, and release claims:

```bash
.venv/bin/python scripts/verify_agent_eval_assets.py
```

## Launch Rule

A release can claim Agent Eval foundation only when:

- API tests cover `agent-eval/artifact`.
- API tests cover `evals/policy` and `agent-eval/report`.
- `scripts/verify_agent_eval_assets.py` passes.
- `scripts/verify_agent_eval_baseline.py --check` passes and emits
  `study-anything-agent-eval-regression-report-v1`.
- `scripts/verify_agent_eval_flow.py` passes on the fake demo path.
- `scripts/run_external_agent_evals.py --tool report --create-session --required` passes against a
  running local API.
- Promptfoo can be invoked through `scripts/run_external_agent_evals.py --tool promptfoo` when the
  release environment permits external Node package installation.
- DeepEval or the labeled native fallback can consume `agent-eval/quality`.
- Retrieval eval can consume rebuilt retrieval results through
  `scripts/run_external_agent_evals.py --tool retrieval`.
- Mock/user-owned HTTP Agent smoke verifies `agent-audit` and can optionally require external Agent usage.
- Docs list the selected mature eval projects and explain why Study Anything does not run judge models by default.

## Claim Boundaries

- `agent-audit.status=verified` means Study Anything observed the required Agent task invocations.
- `agent-eval-policy-v1` means the release gate, optional external adapters, failure classes,
  fixtures, and privacy contract are machine-readable.
- `agent-eval/artifact.status=ready_for_external_eval` means the redacted artifact is structurally
  ready for external tools.
- `agent-eval-report-v1.native_fast_gate.status=pass` means invocation, trajectory, teaching
  quality, and privacy redaction are release-gate ready for that session.
- Promptfoo passing the bundled config means the artifact contract and native gates passed.
- `agent-eval/quality.status=pass` means the deterministic minimum teaching-quality gates passed.
- `retrieval-quality-eval.status=pass` means the retrieval/context handoff gates and privacy invariants
  passed for the scored query.
- `study-anything-agent-eval-regression-report-v1.status=pass` means the current deterministic
  scorecard did not regress against the committed baseline.
- A real DeepEval run means the quality report was consumed through DeepEval's metric interface.
- A real Ragas run or judge-model suite is still required for stronger claims about
  trajectory quality, source-grounding quality, and learning usefulness at scale.
