# Study Anything Codex Plugin Pack

Install the repo-local Skill in Codex or another terminal-capable Agent and let that Agent call the local Study Anything runtime.

## Import Assets

- `skills/study-anything/SKILL.md`
- `skills/study-anything/agents/openai.yaml`
- `platform/packs/codex/pack.json`
- `platform/generated/study-anything-tool-catalog.md`

## Local Runtime

1. Start the local Study Anything runtime with `./START_HERE.command` or `./scripts/start_here.sh`.
2. Import the assets above into codex.
3. Point the host Agent or workspace at `http://127.0.0.1:8000` or your private runtime endpoint.

## Verification

- `./START_HERE.command`
- `python3 scripts/study_anything_cli.py health`
- `API_BASE=http://127.0.0.1:8000 python3 scripts/verify_platform_agent_tools.py`

## Privacy Boundary

Real model credentials, browser access, external app context, and private tools stay in the user's
platform Agent or gateway. Study Anything only owns the local learning workflow, validation,
redacted evidence, and export contracts.

## Known Limitations

- Requires a local checkout or extracted runtime files that can execute shell commands.
- Does not install a marketplace extension automatically.
- Real model credentials stay inside the user's platform Agent or gateway, not Study Anything.
