# Study Anything Release Asset Bootstrap

Version: v0.3.28-alpha
Schema: release-asset-bootstrap-v1

Run `python3 scripts/bootstrap_from_release.py --tag v0.3.28-alpha --runtime metadata-only`
to verify public release assets and platform import readiness.
