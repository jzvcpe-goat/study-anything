# Study Anything Release Asset Adoption

Version: v0.3.26-alpha
Schema: release-asset-adoption-v1

Run `python3 scripts/verify_release_asset_adoption.py --tag v0.3.26-alpha --runtime metadata-only`
to verify GitHub Release assets without launching the app.
