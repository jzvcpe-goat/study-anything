# Study Anything Dual Loop Trust Scenario Pack

Portable metadata-only fixtures and verifiers showing how an AI-generated customer handoff candidate is allowed only when controlled failure and human attention reconstruction both satisfy the Dual Loop gate.

## Start

Run the scenario matrix from an extracted repository or adoption-pack checkout:

```bash
python3 scripts/run_dual_loop_scenario_harness.py run --case all
python3 scripts/verify_dual_loop_scenario_harness.py --check
python3 scripts/cbb_delivery_harness.py run --case all
python3 scripts/verify_cbb_delivery_harness.py --check
```

## Verification

- `python3 scripts/verify_dual_loop_scenario_harness.py --check`
- `python3 scripts/verify_cbb_delivery_harness.py --check`
- `python3 scripts/verify_dual_loop_trust_scenario_pack.py --check`

## Boundary

This pack is local-first and metadata-only. It does not call models, start a
daemon, mutate production, send customer messages, or include raw source text,
raw reports, screenshots, attention streams, secrets, cookies, bearer tokens,
signed URLs, or user-owned Agent credentials.

## Claim Boundary

Current claim: This pack proves deterministic local metadata-only Dual Loop and CBB scenario behavior for customer-delivery readiness.

Not claimed: production deployment approval, real customer acceptance, general model correctness, legal compliance certification, security certification.
